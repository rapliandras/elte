﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading;
using Microsoft.Win32;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using zh.Model;
using zh.ViewModel;

namespace zh
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        #region Fields
        private model _model;
        private viewModel _viewModel;
        private MainWindow _view;
        private DispatcherTimer _timer;
        #endregion
        
        public App()
        {
            Startup += new StartupEventHandler(App_Startup);
        }

        private void App_Startup(object sender, StartupEventArgs e)
        {
            _model = new model();
            _viewModel = new viewModel(_model);
            _viewModel.NewGame += new EventHandler(ViewModel_NewGame);
            _viewModel.ExitGame += new EventHandler(ViewModel_ExitGame);
            _view = new zh.MainWindow();
            _view.DataContext = _viewModel;
            _view.Show();
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += new EventHandler(Timer_Tick);
            _model.GameOver += new EventHandler<ZhEventArgs>(GameOverRecieved);
        }

        #region EventHandlers

        private void ViewModel_NewGame(object sender, EventArgs e)
        {
            _model.NewGame();
            _timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (!_model.GameIsOver)
            _model.advanceTime();
        }

        private void ViewModel_ExitGame(object sender, EventArgs e)
        {
            _view.Close();
        }

        private void GameOverRecieved(object sender, EventArgs e)
        {
            _timer.Stop();
            MessageBox.Show("Sajnálom, az óceán alján porladnak a csontjaid!",
                "Submarine",
                MessageBoxButton.OK,
                MessageBoxImage.Asterisk);
        }


#endregion
    }
}
