﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using zh.Model;

namespace zh.ViewModel
{
    class Field : ViewModelBase
    {
        private States _State;

        /// <summary>
        /// Zároltság lekérdezése, vagy beállítása.
        /// </summary>
        public States MyState
        {
            get { return _State; }
            set
            {
                if (_State != value)
                {
                    _State = value;
                    OnPropertyChanged();
                }
            }
        }

        /// <summary>
        /// Vízszintes koordináta lekérdezése, vagy beállítása.
        /// </summary>
        public Int32 X { get; set; }

        /// <summary>
        /// Függőleges koordináta lekérdezése, vagy beállítása.
        /// </summary>
        public Int32 Y { get; set; }
        public DelegateCommand StepCommand { get; set; }

        public Int32 Number { get; set; }

    }
}
