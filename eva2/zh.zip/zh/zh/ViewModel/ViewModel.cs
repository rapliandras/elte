﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using zh.Model;

namespace zh.ViewModel
{
    class viewModel : ViewModelBase
    {
        private model _model;
        public DelegateCommand NewGameCommand { get; private set; }

        public DelegateCommand ExitCommand { get; private set; }

        public ObservableCollection<Field> Fields { get; set; }
        public String GameTime { get { return TimeSpan.FromSeconds(_model.gameTime).ToString("g"); } }

        public viewModel(model argModel)
        {
            _model = argModel;
            _model.TimesChange += new EventHandler<ZhTimeArg>(GoesTheClock);
            _model.GameStateChanged += new EventHandler<ZhEventArgs>(FieldUpdate);

            Fields = new ObservableCollection<Field>();

            //parancsok
            NewGameCommand = new DelegateCommand(param => { OnNewGame(); });
            ExitCommand = new DelegateCommand(param => { OnExitGame(); });

            GenerateTable();
            RefreshTable();
        }

        private void OnExitGame()
        {
            ExitGame(this, EventArgs.Empty);
        }

        private void OnNewGame()
        {
            if (NewGame != null)
                NewGame(this, EventArgs.Empty);
            GenerateTable();
            _model.GameIsRunning = true;
            OnPropertyChanged("GetViewSize");
        }

        private void GoesTheClock(object sender, ZhTimeArg e)
        {
            OnPropertyChanged("GameTime");
        }

        private void FieldUpdate(object sender, ZhEventArgs e)
        {
            foreach (Field F in Fields)
            {
                if (F.X == e.X && F.Y == e.Y) F.MyState = e.State;
            }
        }

        private void RefreshTable()
        {

            OnPropertyChanged("GameStepCount");
        }
        private void GenerateTable()
        {

            Fields.Clear();
            for (Int32 i = 0; i < _model.MapSize; i++) // inicializáljuk a mezőket
            {
                for (Int32 j = 0; j < _model.MapSize; j++)
                {
                    Fields.Add(new Field
                    {
                        MyState = States.State1,
                        X = i,
                        Y = j,
                        Number = i * _model.MapSize + j, // a gomb sorszáma, amelyet felhasználunk az azonosításhoz
                        StepCommand = new DelegateCommand(param => StepGame(Convert.ToInt32(param)))
                    });
                }
            }
        }

        private void StepGame(Int32 index)
        {
            Field field = Fields[index];

            //! IDE KERÜL AMIT A MOZGATHATO ENTITASNAK KELL CSINALNIA
            _model.CursorMovement(field.X, field.Y);
        }
        #region Events
        public event EventHandler NewGame;

        public event EventHandler ExitGame;

        #endregion
    }
}
