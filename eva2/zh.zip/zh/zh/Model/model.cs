﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zh.Model
{
    public enum States { State1, State2 };

    public struct Coord
    {
        public int x { get; set; }
        public int y { get; set; }
    }
    class model
    {
        #region datafields
        private Coord Entity1_coord;
        public Boolean GameIsRunning { get; set; }
        public Boolean GameIsOver { get; private set; }
        public int MapSize { get; private set; }

        public int gameTime { get; private set; }

        #endregion datafields
        #region Event Handlers
        public event EventHandler<ZhEventArgs> GameOver;
        public event EventHandler<ZhEventArgs> GameStateChanged;
        public event EventHandler<ZhTimeArg> TimesChange;

        #endregion
        #region functions
        public model()
        {
            NewGame();
        }
        public void NewGame()
        {

            //! IMPLEMENT
            Entity1_coord.x = 5;
            Entity1_coord.x = 5;
            gameTime = 0;
            GameIsOver = false;
            MapSize = 50;
        }

        public void advanceTime()
        {
            gameTime++;
            TimesChange(this, new ZhTimeArg(gameTime));
            stimulate();
        }

        public void IsGameOver()
        {
            //! IMPLEMENT
        }

        public void stimulate()
        {
            GameStateChanged(this, new ZhEventArgs(Entity1_coord.x, Entity1_coord.y, States.State1));
            Entity1_coord.x++;
            GameStateChanged(this, new ZhEventArgs(Entity1_coord.x, Entity1_coord.y, States.State2));
            //! IMPLEMENT
        }

        public void CursorMovement(int xparam, int yparam)
        {
            GameStateChanged(this, new ZhEventArgs(Entity1_coord.x, Entity1_coord.y, States.State1));
            Entity1_coord.x = xparam;
            Entity1_coord.y = yparam;
            GameStateChanged(this, new ZhEventArgs(Entity1_coord.x, Entity1_coord.y, States.State2));
        }
        #endregion functions
    }
}
