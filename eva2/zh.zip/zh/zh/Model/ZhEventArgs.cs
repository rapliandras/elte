﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zh.Model
{ 
    public class ZhEventArgs : EventArgs
    {
        public int X { get; private set; }
        public int Y { get; private set; }
        public States State { get; private set; }
        public ZhEventArgs(int paramx, int paramy, States paramstate)
        {
            X = paramx;
            Y = paramy;
            State = paramstate;
        }
        public ZhEventArgs()
        {

        }

    }
    public class ZhTimeArg : EventArgs
    {
        public Int32 _gameTime { get; private set; }
        public ZhTimeArg(Int32 gameTime)
        {
            _gameTime = gameTime;
        }

    }
}
