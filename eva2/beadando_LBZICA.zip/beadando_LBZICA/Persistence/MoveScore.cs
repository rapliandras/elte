﻿namespace BoxGame.Persistence
{
    public enum MoveScore
	{
		NotAllowed = -1,
		Zero = 0,
		One = 1,
		Two = 2
	}
}
