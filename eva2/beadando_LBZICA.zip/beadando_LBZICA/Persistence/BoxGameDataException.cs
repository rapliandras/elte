﻿using System;

namespace BoxGame.Persistence
{
    public class BoxGameDataException : Exception
    {
        public BoxGameDataException()
        {

        }
    }
}
