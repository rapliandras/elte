﻿namespace BoxGame.Persistence
{
    public enum BoxDirection
	{
		Up,
		Down,
		Left,
		Right
	}
}
